#!/bin/bash
for i in {1..10};
do
	mkdir Dir$i
done
