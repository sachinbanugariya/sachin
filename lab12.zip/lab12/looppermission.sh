#!/bin/bash
chmod 755 *.sh
chmod 755 *.java
