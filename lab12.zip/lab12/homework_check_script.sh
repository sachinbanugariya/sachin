#!/bin/bash
all_students=`ls students`
for i in ${all_students};
do
	if [[ -f "students/$i/gettysburg.sh" ]]; then
	#if [[ -n $(find students/$i -maxdepth 1 -iname gettysburg.sh) ]]; then
		chmod 755 students/$i/gettysburg.sh
		sh -i students/$i/gettysburg.sh > students/$i/gettysburgoutput
	else
		echo "student $i : gettysburg.sh does not exist."
        fi
done
