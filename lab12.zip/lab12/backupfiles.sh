#!/bin/bash
all_data=`ls`
for i in ${all_data};
do
	if [[ -f "$i" ]]; then
    		#echo "$i exist"
		cp $i $i.back
	fi
        #echo $i
done
